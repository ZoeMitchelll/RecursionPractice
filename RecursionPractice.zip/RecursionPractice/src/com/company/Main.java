package com.company;

public class Main {

    public static void main(String[] args) {
        countdown(5);
    }

    public static void countdown(int n) {
        if (n == 0) {
            System.out.println("Error");
        } else {
            System.out.println(n);
            countdown(n - 1);
        }
    }
}
